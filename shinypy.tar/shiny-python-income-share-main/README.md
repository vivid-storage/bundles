# Data Visualization with Shiny for Python

## Deploy

```
rsconnect deploy shiny . -n <SERVER-NICKNAME>
```

## Resources

[Posit Connect User Guide - Shiny for Python](https://docs.posit.co/connect/user/shiny-python/)
